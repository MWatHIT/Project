# Contributing

We follow the
[Jupyter Contribution Workflow](https://jupyter.readthedocs.org/en/latest/contrib_guide_code.html#contribution-workflow)
and the [IPython Contributing Guide](https://github.com/ipython/ipython/blob/master/CONTRIBUTING.md).
