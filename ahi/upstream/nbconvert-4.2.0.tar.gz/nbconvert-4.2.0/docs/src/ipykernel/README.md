# IPython Kernel for Jupyter

This package provides the IPython kernel for Jupyter.

## Installation from source

1. `git clone`
2. `cd ipykernel`
3. `pip install -e .`

After that, all normal `ipython` commands will use this newly-installed version of the kernel.
