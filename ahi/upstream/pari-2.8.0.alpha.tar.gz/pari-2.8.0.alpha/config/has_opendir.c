#include <sys/types.h>
#include <dirent.h>
main() { DIR *d = opendir("."); }
