Paths for Jupyter files
=======================

.. module:: jupyter_core.paths

Specific directories
--------------------

.. autofunction:: jupyter_config_dir

.. autofunction:: jupyter_data_dir

.. autofunction:: jupyter_runtime_dir


Search paths
------------

.. autofunction:: jupyter_config_path

.. autofunction:: jupyter_path
