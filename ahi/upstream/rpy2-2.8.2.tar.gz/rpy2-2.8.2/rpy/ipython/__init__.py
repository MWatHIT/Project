from .rmagic import load_ipython_extension
