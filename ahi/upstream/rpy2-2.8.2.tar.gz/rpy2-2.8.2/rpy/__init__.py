
__version_vector__ = ((2,8,2), '')

__version__ = '.'.join([str(x) for x in __version_vector__[0]]) + \
              '' + __version_vector__[1]

