jupyter_client API
==================

.. module:: jupyter_client

.. toctree::
   :maxdepth: 2
   :caption: Jupyter API

   kernelspec
   manager
   client
