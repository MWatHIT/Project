#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_mem_init_memoryspace.c"
