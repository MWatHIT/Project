#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_get_memory.c"
