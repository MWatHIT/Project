#define DINT

#include "../../SuiteSparse/AMD/Source/amd_valid.c"
