#define ZINT
#define FIXQ
#include "../../SuiteSparse/UMFPACK/Source/umf_assemble.c"
