#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_mem_alloc_tail_block.c"
