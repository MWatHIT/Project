#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umfpack_free_symbolic.c"
