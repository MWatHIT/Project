#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_grow_front.c"
