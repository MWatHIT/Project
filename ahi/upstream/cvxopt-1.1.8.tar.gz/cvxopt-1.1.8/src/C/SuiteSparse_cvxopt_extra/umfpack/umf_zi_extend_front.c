#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umf_extend_front.c"
