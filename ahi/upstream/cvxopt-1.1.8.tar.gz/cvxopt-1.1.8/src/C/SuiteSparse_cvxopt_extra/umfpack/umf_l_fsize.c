#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_fsize.c"
