#define DLONG

#include "../../SuiteSparse/AMD/Source/amd_preprocess.c"
