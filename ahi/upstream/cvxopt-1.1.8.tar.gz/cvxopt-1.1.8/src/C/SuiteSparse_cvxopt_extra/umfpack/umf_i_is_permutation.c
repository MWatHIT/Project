#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_is_permutation.c"
