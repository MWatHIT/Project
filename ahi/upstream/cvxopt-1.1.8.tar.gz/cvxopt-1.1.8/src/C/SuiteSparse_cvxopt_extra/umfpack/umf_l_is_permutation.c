#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_is_permutation.c"
