#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_local_search.c"
