#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_mem_free_tail_block.c"
