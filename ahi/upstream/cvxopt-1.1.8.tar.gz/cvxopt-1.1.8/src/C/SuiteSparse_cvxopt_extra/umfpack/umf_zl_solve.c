#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_solve.c"
