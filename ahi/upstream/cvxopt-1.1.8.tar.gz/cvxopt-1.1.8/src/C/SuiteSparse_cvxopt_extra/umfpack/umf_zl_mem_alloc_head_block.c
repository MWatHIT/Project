#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_mem_alloc_head_block.c"
