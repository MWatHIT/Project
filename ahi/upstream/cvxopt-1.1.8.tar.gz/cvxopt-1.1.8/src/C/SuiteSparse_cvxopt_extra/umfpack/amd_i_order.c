#define DINT

#include "../../SuiteSparse/AMD/Source/amd_order.c"
