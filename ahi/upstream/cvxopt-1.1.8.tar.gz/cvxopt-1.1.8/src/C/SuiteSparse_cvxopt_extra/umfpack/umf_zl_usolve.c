#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_usolve.c"
