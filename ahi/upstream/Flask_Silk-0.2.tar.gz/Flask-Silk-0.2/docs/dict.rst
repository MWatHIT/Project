Silk Icon Dictionary
====================

.. automodule:: flask_silk.icons

   :license: `CC BY 2.5 <http://creativecommons.org/licenses/by/2.5>`_ or
             `3.0 <http://creativecommons.org/licenses/by/3.0>`_
