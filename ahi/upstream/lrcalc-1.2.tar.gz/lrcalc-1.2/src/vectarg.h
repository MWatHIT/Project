#ifndef _VECTARG_H
#define _VECTARG_H

#include "vector.h"

vector *get_vect_arg(int ac, char **av);

#endif
