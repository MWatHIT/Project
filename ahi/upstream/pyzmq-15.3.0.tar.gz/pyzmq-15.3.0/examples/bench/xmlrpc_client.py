from timeit import default_timer as timer
from xmlrpclib import ServerProxy

client = ServerProxy('http://localhost:10002')

    