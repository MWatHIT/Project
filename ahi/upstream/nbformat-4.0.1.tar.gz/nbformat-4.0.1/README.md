# The Jupyter Notebook Format

`nbformat` contains the reference implementation of the [Jupyter Notebook format][],
and Python APIs for working with notebooks.

There is also a JSON schema for notebook format versions >= 3.

[Jupyter Notebook format]: http://ipython.org/ipython-doc/stable/notebook/nbformat.html
