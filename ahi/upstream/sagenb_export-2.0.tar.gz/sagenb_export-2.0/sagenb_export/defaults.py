## -*- encoding: utf-8 -*-
"""
Default Values
"""


DOT_SAGE = '~/.sage'
