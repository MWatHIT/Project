version_info = (5, 2, 2)
__version__ = '.'.join(map(str, version_info))
__frontend_version__ = '~1.2.0'
