Contributing
============

We appreciate contributions from the community.

We follow the [IPython Contributing Guide](https://github.com/ipython/ipython/blob/master/CONTRIBUTING.md) and [Jupyter document on Contributing to the Code](https://jupyter.readthedocs.org/en/latest/contrib_guide_code.html)
