cd ../../jupyter-js-widgets
npm install
cd ../docs
npm install
